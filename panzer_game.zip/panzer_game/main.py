import sys

import pygame
import random
sys.setrecursionlimit(2000)

class Tank:
    def __init__(self, x, y, color, player):
        self.starting_x = x  # startwerte für reset
        self.starting_y = y
        self.x = x
        self.y = y
        self.color = color
        self.speed = 5
        self.direction = "down"
        self.image = pygame.image.load("pictures/green_tank_up.png")
        # self.image.fill(color)
        self.player = player
        self.missile = None
        self.rect = pygame.Rect(x + 18, y + 18, 50, 50)

    def set_player(self, playerNr):
        if playerNr == 1:
            player = 1
        if playerNr == 2:
            player = 2
        self.player = player

    def refresh_rect(self):
        if self.direction == "left" or self.direction == "right":
            self.rect = pygame.Rect(self.x + 18, self.y + 18, 73, 50)
        elif self.direction == "up" or self.direction == "down":
            self.rect = pygame.Rect(self.x + 18, self.y + 18, 50, 73)

    def move(self):
        keys = pygame.key.get_pressed()
        # movesound = pygame.mixer.Sound('music/tank_move.mp3')  # for sound
        if self.player == 1:

            keys = pygame.key.get_pressed()
            # movesound = pygame.mixer.Sound('music/tank_move.mp3')  # for sound
            if keys[pygame.K_UP]:
                self.direction = "up"
                self.y -= 5
                self.refresh_rect()
                if self.is_collided():
                    self.y += 5
                self.refresh_rect()
            elif keys[pygame.K_DOWN]:
                self.direction = "down"
                self.y += 5
                self.refresh_rect()
                if self.is_collided():
                    self.y -= 5
                self.refresh_rect()
            elif keys[pygame.K_LEFT]:
                self.direction = "left"
                self.x -= 5
                self.refresh_rect()
                if self.is_collided():
                    self.x += 5
                self.refresh_rect()
            elif keys[pygame.K_RIGHT]:
                self.direction = "right"
                self.x += 5
                self.refresh_rect()
                if self.is_collided():
                    self.x -= 5
                self.refresh_rect()
            if keys[pygame.K_p] or (keys[pygame.K_p] and keys[pygame.K_RIGHT]):
                self.shoot()

        if self.player == 2:

            if keys[pygame.K_w]:

                self.direction = "up"
                self.y -= 5
                self.refresh_rect()
                if self.is_collided():
                    self.y += 5
                self.refresh_rect()

            elif keys[pygame.K_s]:

                self.direction = "down"
                self.y += 5
                self.refresh_rect()
                if self.is_collided():
                    self.y -= 5
                self.refresh_rect()
            elif keys[pygame.K_a]:

                self.direction = "left"
                self.x -= 5
                self.refresh_rect()
                if self.is_collided():
                    self.x += 5
                self.refresh_rect()
            elif keys[pygame.K_d]:

                self.direction = "right"
                self.x += 5
                self.refresh_rect()
                if self.is_collided():
                    self.x -= 5
                self.refresh_rect()
            if keys[pygame.K_SPACE]:
                self.shoot()
        self.change_direction()

    def shoot(self):
        # print("shoot")
        sound = pygame.mixer.Sound('music/tank_blast_1.mp3')  # for sound
        if self.missile == None:
            sound.play()
            if self.direction == "right":
                self.missile = Missile(self.x + 100, self.y + 45, self.direction)
            elif self.direction == "left":
                self.missile = Missile(self.x, self.y + 45, self.direction)
            elif self.direction == "up":
                self.missile = Missile(self.x + 45, self.y, self.direction)
            elif self.direction == "down":
                self.missile = Missile(self.x + 45, self.y + 100, self.direction)

    def draw(self, surface):
        surface.blit(self.image, (self.x, self.y))

    def collision(self, object2):
        return self.rect.colliderect(object2.rect)

    def is_collided(self):
        if self.collision(obstacle1) == True or self.collision(obstacle2) == True or self.collision(
                obstacle3) == True or self.collision(obstacle4) == True or self.collision(
            ceiling) == True or self.collision(floor) == True or self.collision(
            left_wall) == True or self.collision(right_wall) == True:
            return True
        else:
            return False

    def check_hit(self):
        if self.missile.is_collided() == "wall_hit":
            # if self.missile.wallhit_counter < 1:
            if self.missile.direction == "left":
                self.missile.direction = self.missile.direction = "right"
            elif self.missile.direction == "right":
                self.missile.direction = self.missile.direction = "left"
            elif self.missile.direction == "up":
                self.missile.direction = self.missile.direction = "down"
            elif self.missile.direction == "down":
                self.missile.direction = self.missile.direction = "up"
            self.missile.wallhit_counter += 1
            # else:
            # self.missile.wallhit_counter = 0
            self.missile = None
        elif self.missile.collision(tank1):
            self.missile = None
            print("p1_hit")
            tank1.reset()
            tank2.reset()
            obstacle1.randomise()
            obstacle2.randomise()
            obstacle3.randomise()
            obstacle4.randomise()
        elif self.missile.collision(tank2):
            self.missile = None
            print("p2_hit")
            tank2.reset()
            tank1.reset()
            obstacle1.randomise()
            obstacle2.randomise()
            obstacle3.randomise()
            obstacle4.randomise()
        elif tank1.missile is not None and self.missile.collision(tank1.missile) and self.player == 1:
            self.missile = None
        elif tank2.missile is not None and self.missile.collision(tank2.missile) and self.player == 2:
            self.missile = None

    def reset(self):
        self.x = self.starting_x
        self.y = self.starting_y
        self.speed = 5
        self.direction = "down"
        self.missile = None
        self.rect = pygame.Rect(self.starting_x, self.starting_y, 50, 50)
        self.refresh_rect()
        print(self.y, self.x)

    def change_direction(self):
        if self.direction == "right":
            self.image = pygame.image.load("pictures/green_tank_right.png")
        if self.direction == "up":
            self.image = pygame.image.load("pictures/green_tank_up.png")
        if self.direction == "left":
            self.image = pygame.image.load("pictures/green_tank_left.png")
        if self.direction == "down":
            self.image = pygame.image.load("pictures/green_tank_down.png")
        #print("change direction",self.direction)


class Bot(Tank):
    def __init__(self, x, y, color, player):
        super().__init__(x, y, color, player)
        self.i = 0
        self.o = 0
    def move(self):
        # adjust player coordinates for center of the tank

        player_x = tank1.x
        player_y = tank1.y
        x_diff = abs(player_x - self.x)
        y_diff = abs(player_y - self.y)
       # print("x_diff: ",x_diff)
       # print("y_diff: ",y_diff)
        player_relative_x = self.find_player_position()[0]
        player_relative_y = self.find_player_position()[1]

        # dodge mechanic

        missile_x = self.find_missile_position()[0]
        missile_y = self.find_missile_position()[1]
        missile_direction = self.find_missile_position()[2]
        missile_x_diff = abs(missile_x - self.x)
        missile_y_diff = abs(missile_y - self.y)
        if missile_x_diff < 150 and missile_y_diff < 100:
            n = random.randint(0,1)
            if missile_direction == "right" or missile_direction == "left":

                    self.move_down()
            elif missile_direction == "up" or missile_direction == "down":
                if n == 0:
                    self.move_left()
                if n == 1:
                    self.move_right()

        else:

            if player_relative_x == "left":
                if player_relative_y == "top":
                    if x_diff < y_diff and y_diff>=200:
                        self.move_up()
                    elif x_diff > y_diff and x_diff>=200:
                        self.move_left()
                    elif x_diff>=200 and y_diff<200:
                        self.move_down()

                    else:
                        self.move_left()
                elif player_relative_y == "down":
                    if x_diff < y_diff and y_diff>200:
                        self.move_down()
                    elif x_diff > y_diff and x_diff>200:
                        self.move_left()

                    elif x_diff>=200 and y_diff<200:
                        self.move_up()
                    else:
                        self.move_left()
            elif player_relative_x == "right":
                if player_relative_y == "top":
                    if x_diff < y_diff and x_diff>200:
                        self.move_up()
                    elif x_diff > y_diff and x_diff>200:
                        self.move_right()

                    elif x_diff>=200 and y_diff<200:
                        self.move_down()
                    else:
                        self.move_right()
                elif player_relative_y == "down":
                    if x_diff < y_diff and x_diff>200:
                        self.move_down()
                    elif x_diff > y_diff and x_diff>200:
                        self.move_right()
                    elif x_diff>=200 and y_diff<200:
                        self.move_up()

                    else:
                        self.move_right()

            elif player_relative_x == "same":
                if player_relative_y == "top":
                        self.move_up()
                        self.shoot()
                elif player_relative_y == "down":
                        self.move_down()
                        self.shoot()




        self.change_direction()



    def move_up(self):
        self.direction = "up"
        self.y -= self.speed
        self.refresh_rect()
        if self.is_collided():
            self.y += self.speed
            self.move_left()
        self.refresh_rect()
        #self.change_direction()
    def move_down(self):
        self.direction = "down"
        self.y += self.speed
        self.refresh_rect()
        if self.is_collided():
            self.y -= self.speed
            self.move_right()
        self.refresh_rect()
        #self.change_direction()
    def move_left(self):
        self.direction = "left"
        self.x -= self.speed
        self.refresh_rect()
        if self.is_collided():
            self.x += self.speed
            self.move_down()
        self.refresh_rect()
        #self.change_direction()
    def move_right(self):
        self.direction = "right"
        self.x += self.speed
        self.refresh_rect()
        if self.is_collided():
            self.x -= self.speed
            self.move_up()
        self.refresh_rect()
        #self.change_direction()
    def move_random(self):
        i= self.i
        x= self.o
        if x == 0:
            i = random.randint(0, 3)
        if i == 0:
            self.move_up()
        elif i == 1:
            self.move_down()
        elif i == 2:
            self.move_left()
        elif i == 3:
            self.move_right
        x += 1
        if x == 120:
            x = 0
        self.o = x
        self.i = i
        print(self.i)

    def find_missile_position(self):
        # get missile coordinates
        missile_x = 100000
        missile_y = 100000
        missile_direction = None
        if tank1.missile is not None:
            missile_x = tank1.missile.x
            missile_y = tank1.missile.y
            missile_direction = tank1.missile.direction
        missile_position = [missile_x,missile_y,missile_direction]
        return missile_position

    def find_player_position(self):

        # get tank coordinates

        player_x = tank1.x
        player_y = tank1.y


        # find out where player is in relation to the bot

        if player_x < self.x:
            player_relative_x_position = "left"
        elif player_x > self.x:
            player_relative_x_position = "right"
        elif player_x == self.x:
            player_relative_x_position = "same"
        if player_y < self.y:
            player_relative_y_position = "top"
        elif player_y > self.y:
            player_relative_y_position = "down"
        elif player_y == self.y:
            player_relative_y_position = "same"
        player_relative_position = [player_relative_x_position, player_relative_y_position]
        return player_relative_position




class Missile:
    def __init__(self, x, y, direction):
        self.x = x
        self.y = y
        self.direction = direction
        self.speed = 15
        self.image = pygame.Surface((10, 10))
        self.image.fill((255, 36, 0))
        self.rect = pygame.Rect(x, y, 10, 10)
        self.wallhit_counter = 0

    def move(self):

        if self.direction == "up":
            self.y -= self.speed
            self.refresh_rect()
        elif self.direction == "down":
            self.y += self.speed
            self.refresh_rect()
        elif self.direction == "left":
            self.x -= self.speed
            self.refresh_rect()
        elif self.direction == "right":
            self.x += self.speed
            self.refresh_rect()

    def draw(self, surface):
        surface.blit(self.image, (self.x, self.y))

    def refresh_rect(self):
        self.rect = pygame.Rect(self.x, self.y, 10, 10)

    def collision(self, object2):
        return self.rect.colliderect(object2.rect)

    def is_collided(self):
        if self.collision(obstacle1) == True or self.collision(obstacle2) == True or self.collision(
                obstacle3) == True or self.collision(obstacle4) == True or self.collision(
            ceiling) == True or self.collision(floor) == True or self.collision(
            left_wall) == True or self.collision(right_wall) == True:
            return ("wall_hit")
        elif self.collision(tank1) == True or self.collision(tank2) == True:
            return ("player_hit")
        else:
            return "false"


class Obstacle:
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.color = (255, 255, 255)
        self.rect = pygame.Rect(x, y, width, height)

    def draw(self, screen):
        pygame.draw.rect(screen, self.color, (self.x, self.y, self.width, self.height))

    def randomise(self):
        x = random.randint(0, 1100)
        y = random.randint(0, 500)
        width = random.randint(10, 250)
        height = random.randint(10, 250)
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.refresh_rect()
        if tank1.collision(self) or tank2.collision(self):
            self.randomise()

    def refresh_rect(self):
        self.rect = pygame.Rect(self.x, self.y, self.width, self.height)


pygame.init()

# Set up the game window
screen_width = 1200
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Tank Game")

# init tanks and obstacles
tank2 = Bot(1090, 20, (255, 0, 0), 1)
tank1 = Tank(10, 450, (0, 255, 0), 2)
obstacle1 = Obstacle(100, 100, 200, 180)
obstacle2 = Obstacle(500, 150, 50, 250)
obstacle3 = Obstacle(700, 350, 50, 50)
obstacle4 = Obstacle(900, 200, 50, 150)
obstacle1.randomise()
obstacle2.randomise()
obstacle3.randomise()
obstacle4.randomise()

left_wall = Obstacle(0, 0, 20, 600)
right_wall = Obstacle(1180, 0, 20, 600)
ceiling = Obstacle(0, 0, 1200, 20)
floor = Obstacle(0, 580, 1200, 20)

# Load music file
pygame.mixer.music.load("music/tanks_music.mp3")

# Play music
pygame.mixer.music.play()

# init game

running = True
clock = pygame.time.Clock()

# game loop

while True:
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    # Move missile
    if tank1.missile is not None:
        tank1.missile.move()
    if tank2.missile is not None:
        tank2.missile.move()
    tank1.move()
    tank2.move()

    # fill screen
    screen.fill((0, 0, 0))

    # Draw tanks
    screen.fill((0, 0, 0))
    tank1.draw(screen)
    tank2.draw(screen)
    if tank1.missile is not None:
        tank1.missile.draw(screen)
    if tank2.missile is not None:
        tank2.missile.draw(screen)

    # draw obstacles

    obstacle1.draw(screen)
    obstacle2.draw(screen)
    obstacle3.draw(screen)
    obstacle4.draw(screen)
    left_wall.draw(screen)
    right_wall.draw(screen)
    ceiling.draw(screen)
    floor.draw(screen)
    # Update display
    pygame.display.update()

    # Limit frame rate
    clock.tick(60)

    # check hits
    if tank1.missile is not None:
        tank1.check_hit()
    if tank2.missile is not None:
        tank2.check_hit()

# Quit the game
pygame.quit()
